const Loader = () => (
  <div>Loader</div>
);

export default Loader;
