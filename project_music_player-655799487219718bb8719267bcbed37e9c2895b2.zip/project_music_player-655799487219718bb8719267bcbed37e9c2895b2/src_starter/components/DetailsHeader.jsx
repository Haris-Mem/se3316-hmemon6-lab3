const DetailsHeader = () => (
  <div>DetailsHeader</div>
);

export default DetailsHeader;
