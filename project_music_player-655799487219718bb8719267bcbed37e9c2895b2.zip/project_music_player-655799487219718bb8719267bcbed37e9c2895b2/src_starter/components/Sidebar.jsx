const Sidebar = () => (
  <div>Sidebar</div>
);

export default Sidebar;
