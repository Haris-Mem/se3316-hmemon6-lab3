const SongBar = () => (
  <div>SongBar</div>
);

export default SongBar;
