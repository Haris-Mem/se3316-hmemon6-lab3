const Discover = () => <div>Discover</div>;

export default Discover;
